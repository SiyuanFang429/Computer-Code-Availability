function [sum_lastdata,mistake_num]=Predict_one_by_on(Excel_Path,Excel_Path2)
%UNTITLED4 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
mistake_num=0;
try
    if  isequal(Excel_Path,'')&&isequal(Excel_Path2,'')%��ֹѡ����ļ���
        msgbox('no excel you selected');
    else 
        h=waitbar(0,'�����������Ժ�......','name','���챳���б�');
        [~,~,initial_raw] = xlsread(Excel_Path);  
        [~,~,initial_raw2] = xlsread(Excel_Path2);  
    end
    [~,sum_column]=size(initial_raw);
    [sum_row2,~]=size(initial_raw2);
    attribute_name=['classification','accuracy ','confidence',initial_raw(1,1:end)];
    sum_flwrClass=[];

    for sample_index=2:1:sum_row2
        waitbar((sample_index-2)/(sum_row2-1),h,['�����������Ժ�......(',num2str(sample_index-1),'/',num2str(sum_row2-1),')'],'name','���챳���б�')
        test_data=initial_raw2([1,sample_index],:);
        raw=initial_raw;
        for i=sum_column:-1:18
            index_biaoji=0;
            if isnan(cell2mat(test_data(2,i)))
                    index_biaoji=1;     
            end
            if index_biaoji==1
                test_data(:,i)=[];
                raw(:,i)=[];
            end
        end
        data=[];
        raw(1,:)=[];
        %����Ԥ����
        for i=1:3   
            index_list{i}=find(cell2mat(raw(:,1))==i);
            sum_list{i}=raw(index_list{i},1:end);   
            sum_list_zhi{i}=raw(index_list{i},18:end); 
            sum_list{i}(any(isnan(cell2mat(sum_list_zhi{i})),2),:)=[];
            sum_list2{i}=Chongxin_Eliminate_normal2(sum_list{i},3);
            data=[data;sum_list2{i}];
            count_list{i}=size(find(cell2mat(data(:,1))==i),1);   
        end

        Species=cell2mat(data(:,1));

        CvIndices = crossvalind('LeaveMOut',Species,50);

        Test=data(CvIndices~=1,:);
        Train=data(CvIndices==1,:);

        P_train=cell2mat(Train(:,18:end));
        T_train=cell2mat(Train(:,1));

        P_test2=cell2mat(Test(:,18:end));
        T_test2=cell2mat(Test(:,1));

        P_test1=cell2mat(test_data(2,18:end));

        Mdl = TreeBagger(200,P_train,T_train,'OOBPrediction','On','Method','classification','OOBPredictorImportance','on','PredictorSelection','curvature');
        [flwrClass,~,~] = predict(Mdl,P_test1);%��������Ԥ��
        [flwrClass2,~,~] = predict(Mdl,P_test2);%���ݿ��ڲ�Ԥ��

        sim =length(find(str2num(char(flwrClass2)) == str2num(char(flwrClass)) & T_test2 == str2num(char(flwrClass))));
        Accuracy_Rate(sample_index-1,:)=sim/length(find(T_test2 == str2num(char(flwrClass))))*100;
        Confidence_Rate(sample_index-1,:)=sim/length(find(str2num(char(flwrClass2)) == str2num(char(flwrClass))))*100;

        sum_flwrClass(sample_index-1,:)=str2num(char(flwrClass));
        %sum_test(sample_index-1,:)=T_test1;
    end
    close(h)
    %%
    % ��¼������
    sum_lastdata=[attribute_name;[num2cell([sum_flwrClass,Accuracy_Rate,Confidence_Rate]),initial_raw2(2:end,:)]];
catch
    mistake_num=1;
    if exist('h')
        close(h);
    end
    sum_lastdata=[];
end
end

