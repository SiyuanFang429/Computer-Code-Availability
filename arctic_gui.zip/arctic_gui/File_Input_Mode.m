function varargout = File_Input_Mode(varargin)
% FILE_INPUT_MODE MATLAB code for File_Input_Mode.fig
%      FILE_INPUT_MODE, by itself, creates a new FILE_INPUT_MODE or raises the existing
%      singleton*.
%
%      H = FILE_INPUT_MODE returns the handle to a new FILE_INPUT_MODE or the handle to
%      the existing singleton*.
%
%      FILE_INPUT_MODE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FILE_INPUT_MODE.M with the given input arguments.
%
%      FILE_INPUT_MODE('Property','Value',...) creates a new FILE_INPUT_MODE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before File_Input_Mode_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to File_Input_Mode_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help File_Input_Mode

% Last Modified by GUIDE v2.5 03-Jan-2020 15:37:24

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @File_Input_Mode_OpeningFcn, ...
                   'gui_OutputFcn',  @File_Input_Mode_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before File_Input_Mode is made visible.
function File_Input_Mode_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to File_Input_Mode (see VARARGIN)

% Choose default command line output for File_Input_Mode
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes File_Input_Mode wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = File_Input_Mode_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in PB_XZSJK.
function PB_XZSJK_Callback(hObject, eventdata, handles)
% hObject    handle to PB_XZSJK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[SJK_Filename, SJK_Pathname]=uigetfile({'*.xlsx','*.xls'},'��ѡ���ļ�'); 
if isequal(SJK_Filename,0) || isequal(SJK_Pathname,0)
    errordlg('User clicked Cancel.');
    return;
end
set( handles.E_SJKWJ,'String',[SJK_Pathname,SJK_Filename]);
guidata(hObject, handles);


function E_SJKWJ_Callback(hObject, eventdata, handles)
% hObject    handle to E_SJKWJ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_SJKWJ as text
%        str2double(get(hObject,'String')) returns contents of E_SJKWJ as a double


% --- Executes during object creation, after setting all properties.
function E_SJKWJ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_SJKWJ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PB_CSWJ.
function PB_CSWJ_Callback(hObject, eventdata, handles)
% hObject    handle to PB_CSWJ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[CS_Filename, CS_Pathname]=uigetfile({'*.xlsx','*.xls'},'��ѡ���ļ�'); 
if isequal(CS_Filename,0) || isequal(CS_Pathname,0)
    errordlg('User clicked Cancel.');
    return;
end
set( handles.E_CSWJ,'String',[CS_Pathname,CS_Filename]);
set( handles.E_SCWJM,'String',['discrimination_result-',CS_Filename]);
guidata(hObject, handles);


function E_CSWJ_Callback(hObject, eventdata, handles)
% hObject    handle to E_CSWJ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_CSWJ as text
%        str2double(get(hObject,'String')) returns contents of E_CSWJ as a double


% --- Executes during object creation, after setting all properties.
function E_CSWJ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_CSWJ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PB_SCWJJ.
function PB_SCWJJ_Callback(hObject, eventdata, handles)
% hObject    handle to PB_SCWJJ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
SCWJJ_Pathname=uigetdir('��ѡ���ļ�'); 
if isequal(SCWJJ_Pathname,0)
    errordlg('User clicked Cancel.');
    return;
end
set( handles.E_SCWJJ,'String',SCWJJ_Pathname);
guidata(hObject, handles);



function E_SCWJJ_Callback(hObject, eventdata, handles)
% hObject    handle to E_SCWJJ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_SCWJJ as text
%        str2double(get(hObject,'String')) returns contents of E_SCWJJ as a double


% --- Executes during object creation, after setting all properties.
function E_SCWJJ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_SCWJJ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_SCWJM_Callback(hObject, eventdata, handles)
% hObject    handle to E_SCWJM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_SCWJM as text
%        str2double(get(hObject,'String')) returns contents of E_SCWJM as a double


% --- Executes during object creation, after setting all properties.
function E_SCWJM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_SCWJM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PB_JZPB.
function PB_JZPB_Callback(hObject, eventdata, handles)
% hObject    handle to PB_JZPB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if  ~exist(get(handles.E_SJKWJ,'string'),'file')
    errordlg('���ݿ�ѡ�����','������Ϣ');
    return;
end
if  ~exist(get(handles.E_CSWJ,'string'),'file')
    errordlg('��������ѡ�����','������Ϣ');
    return;
end
if  ~exist(get(handles.E_SCWJJ,'string'),'dir')
    errordlg('����ļ���ѡ�����','������Ϣ');
    return;
end
[PBJG_data,mistake_num]=Predict_one_by_on(get(handles.E_SJKWJ,'string'),get(handles.E_CSWJ,'string'));
if mistake_num==1
    errordlg('��Ǹ�����ݴ��������жϣ�','������Ϣ');
    return;
else
    xlswrite(fullfile(get(handles.E_SCWJJ,'string'),get(handles.E_SCWJM,'string')),PBJG_data);
    sel=questdlg('�б���ɣ��Ƿ�򿪽���ļ�','��׼�б����','Yes','No','Yes');
    switch sel
        case 'Yes'
            winopen(fullfile(get(handles.E_SCWJJ,'string'),get(handles.E_SCWJM,'string')));
        case 'No'
            msgbox('���');
    end
end
return;
guidata(hObject, handles);

% --- Executes on button press in PB_KSPB.
function PB_KSPB_Callback(hObject, eventdata, handles)
% hObject    handle to PB_KSPB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if  ~exist(get(handles.E_SJKWJ,'string'),'file')
    errordlg('���ݿ�ѡ�����','������Ϣ');
    return;
end
if  ~exist(get(handles.E_CSWJ,'string'),'file')
    errordlg('��������ѡ�����','������Ϣ');
    return;
end
if  ~exist(get(handles.E_SCWJJ,'string'),'dir')
    errordlg('����ļ���ѡ�����','������Ϣ');
    return;
end
[PBJG_data,mistake_num]=Predict_fast(get(handles.E_SJKWJ,'string'),get(handles.E_CSWJ,'string'));
if mistake_num==1
    errordlg('��Ǹ�����ݴ��������жϣ�','������Ϣ');
    return;
else
    xlswrite(fullfile(get(handles.E_SCWJJ,'string'),get(handles.E_SCWJM,'string')),PBJG_data);
    sel=questdlg('�б���ɣ��Ƿ�򿪽���ļ�','�����б����','Yes','No','Yes');
    switch sel
        case 'Yes'
            winopen(fullfile(get(handles.E_SCWJJ,'string'),get(handles.E_SCWJM,'string')));
        case 'No'
            msgbox('���');
    end
end
guidata(hObject, handles);



% --- Executes on button press in PB_CKGS.
function PB_CKGS_Callback(hObject, eventdata, handles)
% hObject    handle to PB_CKGS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
winopen('Reference_SRWJ.xlsx');


% --- Executes on button press in PB_SJSRPB.
function PB_SJSRPB_Callback(hObject, eventdata, handles)
% hObject    handle to PB_SJSRPB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Single_Data_Input_Mode;
close(File_Input_Mode);


% --- Executes on button press in PB_QKXX.
function PB_QKXX_Callback(hObject, eventdata, handles)
% hObject    handle to PB_QKXX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(findobj(handles.UP_WJSRPB,'style','edit'),'string','');
guidata(hObject, handles);

% --- Executes on button press in PB_SJKCKGS.
function PB_SJKCKGS_Callback(hObject, eventdata, handles)
% hObject    handle to PB_SJKCKGS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
winopen('Reference_SJKWJ.xlsx');


% --- Executes during object creation, after setting all properties.
function P_WJSRPB2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to P_WJSRPB2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --------------------------------------------------------------------
function Menu_GN_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_GN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Menu_FHZJM_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_FHZJM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Enlglish_Main_Interface;
close(File_Input_Mode);


% --------------------------------------------------------------------
function Menu_SJSRGZPB_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_SJSRGZPB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Single_Data_Input_Mode;
close(File_Input_Mode);


% --------------------------------------------------------------------
function Menu_YJYHFY_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_YJYHFY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Enlglish_Distribution;
close(Enlglish_File_Input_Discrimination);


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
