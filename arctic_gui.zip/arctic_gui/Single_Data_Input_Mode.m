function varargout = Single_Data_Input_Mode(varargin)
% SINGLE_DATA_INPUT_MODE MATLAB code for Single_Data_Input_Mode.fig
%      SINGLE_DATA_INPUT_MODE, by itself, creates a new SINGLE_DATA_INPUT_MODE or raises the existing
%      singleton*.
%
%      H = SINGLE_DATA_INPUT_MODE returns the handle to a new SINGLE_DATA_INPUT_MODE or the handle to
%      the existing singleton*.
%
%      SINGLE_DATA_INPUT_MODE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SINGLE_DATA_INPUT_MODE.M with the given input arguments.
%
%      SINGLE_DATA_INPUT_MODE('Property','Value',...) creates a new SINGLE_DATA_INPUT_MODE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Single_Data_Input_Mode_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Single_Data_Input_Mode_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Single_Data_Input_Mode

% Last Modified by GUIDE v2.5 03-Jan-2020 15:13:23

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Single_Data_Input_Mode_OpeningFcn, ...
                   'gui_OutputFcn',  @Single_Data_Input_Mode_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Single_Data_Input_Mode is made visible.
function Single_Data_Input_Mode_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Single_Data_Input_Mode (see VARARGIN)

% Choose default command line output for Single_Data_Input_Mode
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Single_Data_Input_Mode wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Single_Data_Input_Mode_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function E_YPBH_Callback(hObject, eventdata, handles)
% hObject    handle to E_YPBH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_YPBH as text
%        str2double(get(hObject,'String')) returns contents of E_YPBH as a double
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function E_YPBH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_YPBH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_GZPBBG_Callback(hObject, eventdata, handles)
% hObject    handle to E_GZPBBG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_GZPBBG as text
%        str2double(get(hObject,'String')) returns contents of E_GZPBBG as a double


% --- Executes during object creation, after setting all properties.
function E_GZPBBG_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_GZPBBG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PB_SJKXZ.
function PB_SJKXZ_Callback(hObject, eventdata, handles)
% hObject    handle to PB_SJKXZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[SJK_Filename, SJK_Pathname]=uigetfile({'*.xlsx','*.xls'},'��ѡ���ļ�'); 
if isequal(SJK_Filename,0) || isequal(SJK_Pathname,0)
    errordlg('User clicked Cancel.');
    return;
end
set( handles.E_SJKXZ,'String',[SJK_Pathname,SJK_Filename]);
guidata(hObject, handles);


function E_SJKXZ_Callback(hObject, eventdata, handles)
% hObject    handle to E_SJKXZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_SJKXZ as text
%        str2double(get(hObject,'String')) returns contents of E_SJKXZ as a double


% --- Executes during object creation, after setting all properties.
function E_SJKXZ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_SJKXZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PB_PBFX.
function PB_PBFX_Callback(hObject, eventdata, handles)
% hObject    handle to PB_PBFX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if  ~exist(get(handles.E_SJKXZ,'string'),'file')
    errordlg('���ݿ�ѡ�����','������Ϣ');
    return;
end
PB_name={'SIO2(WT%)';'TIO2(WT%)';'AL2O3(WT%)';'FEOT(WT%)';'MNO(WT%)';'MGO(WT%)';'CAO(WT%)';'NA2O(WT%)';'K2O(WT%)';'P2O5(WT%)';...
        'CS(PPM)';'PB(PPM)';'BA(PPM)';'TH(PPM)';'LA(PPM)';'TA(PPM)';'NB(PPM)';'ZR(PPM)';'HF(PPM)';'SR(PPM)';'SM(PPM)';'YB(PPM)';'Y(PPM)';'V(PPM)';'SC(PPM)';'CR(PPM)'};
PB_dataset={get(handles.E_SIO2,'string');get(handles.E_TIO2,'string');get(handles.E_AL2O3,'string');get(handles.E_FEOT,'string');get(handles.E_MNO,'string');...
            get(handles.E_MGO,'string');get(handles.E_CAO,'string');get(handles.E_NA2O,'string');get(handles.E_K2O,'string');get(handles.E_P2O5,'string');...
            get(handles.E_CS,'string');get(handles.E_PB,'string');get(handles.E_BA,'string');get(handles.E_TH,'string');get(handles.E_LA,'string');...
            get(handles.E_TA,'string');get(handles.E_NB,'string');get(handles.E_ZR,'string');get(handles.E_HF,'string');get(handles.E_SR,'string');...
            get(handles.E_SM,'string');get(handles.E_YB,'string');get(handles.E_Y,'string');get(handles.E_V,'string');get(handles.E_SC,'string');get(handles.E_CR,'string')};
delete('DefaultFile.xlsx')
xlswrite('DefaultFile.xlsx',{'NUMBER','SETTING','YEAR','CITATION','SAMPLE NAME','UNIQUE_ID','LOCATION','ROCK TYPE','ROCK NAME',...
                             'AGE (MIN.)','AGE (MAX.)','GEOLOGICAL AGE','TYPE OF MATERIAL','LATITUDE (MIN.)','LONGITUDE (MIN.)',...
                             'LATITUDE (MAX.)','LONGITUDE (MAX.)'},'Sheet1','A1');
xlswrite('DefaultFile.xlsx',[PB_name,PB_dataset]','Sheet1','R1');
[PBJG_data,mistake_num]=Predict_fast(get(handles.E_SJKXZ,'string'),'DefaultFile.xlsx');
if mistake_num==1
    errordlg('��Ǹ�����ݴ��������жϣ�','������Ϣ');
    return;
else
    classfication_name={'Intra Continental','Convergent Margins','Oceanic'};
    for i=size(PB_dataset,1):-1:1
        if isempty(cell2mat(PB_dataset(i)))
            PB_dataset(i)=[];
            PB_name(i)=[];
        end
    end
    for i=1:size(PB_name)
        PB_data{i,:}=strcat(PB_name{i},':',PB_dataset{i});
    end
    PB_data=[['Sample No.',get(handles.E_YPBH,'string')];PB_data;...
             strcat('The discriminant classification of the input data: ',classfication_name(str2num(cell2mat(PBJG_data(2,1)))));...
             ['Database self-checking accuracy rate: ',num2str(cell2mat(PBJG_data(2,2))),'%'];...
             ['Database self-checking confidence rate: ',num2str(cell2mat(PBJG_data(2,3))),'%'];' '];
    delete('DefaultFile.xlsx');
    set(handles.E_GZPBBG,'string',PB_data);  
end

% PB_dataset={['��Ʒ���   :',get(handles.E_YPBH,'string')];['SIO2(WT%):',get(handles.E_SIO2,'string')];['TIO2(WT%):',get(handles.E_TIO2,'string')];...
%             ['AL2O(WT%):',get(handles.E_AL2O3,'string')];['FEOT(WT%):',get(handles.E_FEOT,'string')];['MNO  (WT%):',get(handles.E_MNO,'string')];...
%             ['MGO  (WT%):',get(handles.E_MGO,'string')];['CAO  (WT%):',get(handles.E_CAO,'string')];['NA2O(WT%):',get(handles.E_NA2O,'string')];...
%             ['K2O  (WT%):',get(handles.E_K2O,'string')];['P2O5(WT%):',get(handles.E_P2O5,'string')];...
%             ['CS(PPM):',get(handles.E_CS,'string')];['PB(PPM):',get(handles.E_PB,'string')];['BA(PPM):',get(handles.E_BA,'string')];['TH(PPM):',get(handles.E_TH,'string')];...
%             ['LA(PPM):',get(handles.E_LA,'string')];['TA(PPM):',get(handles.E_TA,'string')];['NB(PPM):',get(handles.E_NB,'string')];['ZR(PPM):',get(handles.E_ZR,'string')];...
%             ['HF(PPM):',get(handles.E_HF,'string')];['SR(PPM):',get(handles.E_SR,'string')];['SM(PPM):',get(handles.E_SM,'string')];['YB(PPM):',get(handles.E_YB,'string')];...
%             ['Y  (PPM):',get(handles.E_Y,'string')];['V  (PPM):',get(handles.E_V,'string')];['SC(PPM):',get(handles.E_SC,'string')];['CR(PPM):',get(handles.E_CR,'string')]};
 
guidata(hObject, handles);

% --- Executes on button press in PB_DCBG.
function PB_DCBG_Callback(hObject, eventdata, handles)
% hObject    handle to PB_DCBG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    PathName  = uigetdir('��ѡ������ļ���');
    edit_data=get(handles.E_GZPBBG,'string');
    file_txt=fopen(fullfile(PathName,[get(handles.E_YPBH,'string'),'_output.txt']),'w');
    for i = 1:size(edit_data, 1)
        fprintf(file_txt,'%s\r\n',edit_data{i,:});
    end
    fclose(file_txt);
catch
    fclose(file_txt);
    msgbox('����ʧ�ܣ�');
    return;
end
msgbox('�����ɹ���')
%save(fullfile(PathName,[get(handles.E_YPBH,'string'),'_output.txt']),'file_txt','-ascii');
guidata(hObject, handles);


% --- Executes on button press in PB_WJSRPB.
function PB_WJSRPB_Callback(hObject, eventdata, handles)
% hObject    handle to PB_WJSRPB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
File_Input_Mode;
close(Single_Data_Input_Mode);


% --- Executes on button press in PB_QKSJ.
function PB_QKSJ_Callback(hObject, eventdata, handles)
% hObject    handle to PB_QKSJ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(findobj([handles.UP_ZLYS,handles.UP_WLYS,handles.UP_QTHS],'style','edit'),'string','');
set(handles.E_YPBH,'string','');
guidata(hObject, handles);


% --- Executes on button press in PB_QUBC.
function PB_QUBC_Callback(hObject, eventdata, handles)
% hObject    handle to PB_QUBC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(findobj(handles.UP_SJSRPB,'style','edit'),'string','');
guidata(hObject, handles);



function E_FE2O3_Callback(hObject, eventdata, handles)
% hObject    handle to E_FE2O3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_FE2O3 as text
%        str2double(get(hObject,'String')) returns contents of E_FE2O3 as a double


% --- Executes during object creation, after setting all properties.
function E_FE2O3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_FE2O3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_FEO_Callback(hObject, eventdata, handles)
% hObject    handle to E_FEO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_FEO as text
%        str2double(get(hObject,'String')) returns contents of E_FEO as a double


% --- Executes during object creation, after setting all properties.
function E_FEO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_FEO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_FE2O3T_Callback(hObject, eventdata, handles)
% hObject    handle to E_FE2O3T (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_FE2O3T as text
%        str2double(get(hObject,'String')) returns contents of E_FE2O3T as a double


% --- Executes during object creation, after setting all properties.
function E_FE2O3T_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_FE2O3T (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PB_HS.
function PB_HS_Callback(hObject, eventdata, handles)
% hObject    handle to PB_HS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if  isempty(get(handles.E_FE2O3T,'String'))&&(isempty(get(handles.E_FEO,'String'))||isempty(get(handles.E_FE2O3,'String')))
    errordlg('��׼ȷ��д������','������Ϣ');
    set(handles.E_FEOT,'String','');
else
    [mistake_value,FEOT_value]=FE_conversion(get(handles.E_FE2O3T,'String'),get(handles.E_FEO,'String'),get(handles.E_FE2O3,'String'));
    if mistake_value==1
        errordlg('����ʧ�ܣ�','������Ϣ');
    else
        set(handles.E_FEOT,'String',FEOT_value);
    end
end
guidata(hObject, handles);


% --- Executes on button press in PB_QTQK.
function PB_QTQK_Callback(hObject, eventdata, handles)
% hObject    handle to PB_QTQK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(findobj(handles.UP_QTHS,'style','edit'),'string','');
guidata(hObject, handles);



function E_CS_Callback(hObject, eventdata, handles)
% hObject    handle to E_CS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_CS as text
%        str2double(get(hObject,'String')) returns contents of E_CS as a double


% --- Executes during object creation, after setting all properties.
function E_CS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_CS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_PB_Callback(hObject, eventdata, handles)
% hObject    handle to E_PB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_PB as text
%        str2double(get(hObject,'String')) returns contents of E_PB as a double


% --- Executes during object creation, after setting all properties.
function E_PB_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_PB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_BA_Callback(hObject, eventdata, handles)
% hObject    handle to E_BA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_BA as text
%        str2double(get(hObject,'String')) returns contents of E_BA as a double


% --- Executes during object creation, after setting all properties.
function E_BA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_BA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_TH_Callback(hObject, eventdata, handles)
% hObject    handle to E_TH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_TH as text
%        str2double(get(hObject,'String')) returns contents of E_TH as a double


% --- Executes during object creation, after setting all properties.
function E_TH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_TH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_LA_Callback(hObject, eventdata, handles)
% hObject    handle to E_LA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_LA as text
%        str2double(get(hObject,'String')) returns contents of E_LA as a double


% --- Executes during object creation, after setting all properties.
function E_LA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_LA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_TA_Callback(hObject, eventdata, handles)
% hObject    handle to E_TA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_TA as text
%        str2double(get(hObject,'String')) returns contents of E_TA as a double


% --- Executes during object creation, after setting all properties.
function E_TA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_TA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_NB_Callback(hObject, eventdata, handles)
% hObject    handle to E_NB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_NB as text
%        str2double(get(hObject,'String')) returns contents of E_NB as a double


% --- Executes during object creation, after setting all properties.
function E_NB_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_NB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_ZR_Callback(hObject, eventdata, handles)
% hObject    handle to E_ZR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_ZR as text
%        str2double(get(hObject,'String')) returns contents of E_ZR as a double


% --- Executes during object creation, after setting all properties.
function E_ZR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_ZR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_HF_Callback(hObject, eventdata, handles)
% hObject    handle to E_HF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_HF as text
%        str2double(get(hObject,'String')) returns contents of E_HF as a double


% --- Executes during object creation, after setting all properties.
function E_HF_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_HF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_SR_Callback(hObject, eventdata, handles)
% hObject    handle to E_SR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_SR as text
%        str2double(get(hObject,'String')) returns contents of E_SR as a double


% --- Executes during object creation, after setting all properties.
function E_SR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_SR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_SM_Callback(hObject, eventdata, handles)
% hObject    handle to E_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_SM as text
%        str2double(get(hObject,'String')) returns contents of E_SM as a double


% --- Executes during object creation, after setting all properties.
function E_SM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_YB_Callback(hObject, eventdata, handles)
% hObject    handle to E_YB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_YB as text
%        str2double(get(hObject,'String')) returns contents of E_YB as a double


% --- Executes during object creation, after setting all properties.
function E_YB_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_YB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_Y_Callback(hObject, eventdata, handles)
% hObject    handle to E_Y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_Y as text
%        str2double(get(hObject,'String')) returns contents of E_Y as a double


% --- Executes during object creation, after setting all properties.
function E_Y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_Y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_V_Callback(hObject, eventdata, handles)
% hObject    handle to E_V (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_V as text
%        str2double(get(hObject,'String')) returns contents of E_V as a double


% --- Executes during object creation, after setting all properties.
function E_V_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_V (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_SC_Callback(hObject, eventdata, handles)
% hObject    handle to E_SC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_SC as text
%        str2double(get(hObject,'String')) returns contents of E_SC as a double


% --- Executes during object creation, after setting all properties.
function E_SC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_SC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_CR_Callback(hObject, eventdata, handles)
% hObject    handle to E_CR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_CR as text
%        str2double(get(hObject,'String')) returns contents of E_CR as a double


% --- Executes during object creation, after setting all properties.
function E_CR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_CR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_SIO2_Callback(hObject, eventdata, handles)
% hObject    handle to E_SIO2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_SIO2 as text
%        str2double(get(hObject,'String')) returns contents of E_SIO2 as a double


% --- Executes during object creation, after setting all properties.
function E_SIO2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_SIO2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_TIO2_Callback(hObject, eventdata, handles)
% hObject    handle to E_TIO2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_TIO2 as text
%        str2double(get(hObject,'String')) returns contents of E_TIO2 as a double


% --- Executes during object creation, after setting all properties.
function E_TIO2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_TIO2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_AL2O3_Callback(hObject, eventdata, handles)
% hObject    handle to E_AL2O3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_AL2O3 as text
%        str2double(get(hObject,'String')) returns contents of E_AL2O3 as a double


% --- Executes during object creation, after setting all properties.
function E_AL2O3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_AL2O3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_FEOT_Callback(hObject, eventdata, handles)
% hObject    handle to E_FEOT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_FEOT as text
%        str2double(get(hObject,'String')) returns contents of E_FEOT as a double


% --- Executes during object creation, after setting all properties.
function E_FEOT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_FEOT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_MNO_Callback(hObject, eventdata, handles)
% hObject    handle to E_MNO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_MNO as text
%        str2double(get(hObject,'String')) returns contents of E_MNO as a double


% --- Executes during object creation, after setting all properties.
function E_MNO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_MNO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_MGO_Callback(hObject, eventdata, handles)
% hObject    handle to E_MGO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_MGO as text
%        str2double(get(hObject,'String')) returns contents of E_MGO as a double


% --- Executes during object creation, after setting all properties.
function E_MGO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_MGO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_CAO_Callback(hObject, eventdata, handles)
% hObject    handle to E_CAO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_CAO as text
%        str2double(get(hObject,'String')) returns contents of E_CAO as a double


% --- Executes during object creation, after setting all properties.
function E_CAO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_CAO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_NA2O_Callback(hObject, eventdata, handles)
% hObject    handle to E_NA2O (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_NA2O as text
%        str2double(get(hObject,'String')) returns contents of E_NA2O as a double


% --- Executes during object creation, after setting all properties.
function E_NA2O_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_NA2O (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_K2O_Callback(hObject, eventdata, handles)
% hObject    handle to E_K2O (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_K2O as text
%        str2double(get(hObject,'String')) returns contents of E_K2O as a double


% --- Executes during object creation, after setting all properties.
function E_K2O_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_K2O (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_P2O5_Callback(hObject, eventdata, handles)
% hObject    handle to E_P2O5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_P2O5 as text
%        str2double(get(hObject,'String')) returns contents of E_P2O5 as a double


% --- Executes during object creation, after setting all properties.
function E_P2O5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_P2O5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function Menu_GN_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_GN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Menu_FHZJM_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_FHZJM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Enlglish_Main_Interface;
close(Single_Data_Input_Mode);

% --------------------------------------------------------------------
function Menu_WJSRPB_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_WJSRPB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
File_Input_Mode;
close(Single_Data_Input_Mode);


% --------------------------------------------------------------------
function Menu_YJFYJX_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_YJFYJX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Enlglish_Distribution;
close(Enlglish_Data_Input_Discrimination);


% --- Executes on selection change in PM_PBYSTJ.
function PM_PBYSTJ_Callback(hObject, eventdata, handles)
% hObject    handle to PM_PBYSTJ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns PM_PBYSTJ contents as cell array
%        contents{get(hObject,'Value')} returns selected item from PM_PBYSTJ


% --- Executes during object creation, after setting all properties.
function PM_PBYSTJ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PM_PBYSTJ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
