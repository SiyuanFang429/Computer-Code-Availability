function [mistake_value,FEOT] = FE_conversion(FE2O3T,FEO,FE2O3)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
mistake_value=0;
try
    FE=55.85;
    O=16;
    if ~isempty(FE2O3T)
        FE2O3T=str2num(FE2O3T);
        FEOT=num2str(FE2O3T/(FE*2+O*3)*2*(FE+O));
    elseif ~isempty(FE2O3)&&~isempty(FEO)
        FE2O3=str2num(FE2O3);
        FEO=str2num(FEO);
        FEOT=num2str(FE2O3/(FE*2+O*3)*2*(FE+O)+FEO);
    end
catch
    mistake_value=1;
    FEO='';
end
end

